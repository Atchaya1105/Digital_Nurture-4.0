public class DataTypeDemo {
    public static void main(String[] args) {
        int age = 25;
        float height = 5.9f;
        double weight = 65.7;
        char grade = 'A';
        boolean isPassed = true;

        System.out.println("Integer (age): " + age);
        System.out.println("Float (height): " + height);
        System.out.println("Double (weight): " + weight);
        System.out.println("Character (grade): " + grade);
        System.out.println("Boolean (isPassed): " + isPassed);
    }
}
