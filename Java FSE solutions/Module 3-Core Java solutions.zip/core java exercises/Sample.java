public class Sample {
    public void greet() {
        System.out.println("Hello!");
    }
}
